# Visual Workflow

Compiled package from https://github.com/etoilestar/dsh-Visual-Workflow at 420d89c5f0a93d1f53708e329c3781fe2c051978 (0.11.0). Model weights are supplied by the offline packaging step.
