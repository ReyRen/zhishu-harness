import type { CollabChannel } from './collab.js';
/** 父代理提示词变体（三情况组装分发）：orchestrator=纯编排 / hybrid=编排+自执行 / executor=纯执行。 */
export type ParentPromptVariant = 'orchestrator' | 'hybrid' | 'executor';
/**
 * 编排系模板（情况1/2）的入参（中文注释每个字段）。
 * `facts` 是同一 run 内字节稳定的静态事实；`dynamic` 是仅注入末段的动态状态。
 */
export interface OrchestrationDirectiveParams {
    facts: {
        /** 工作流名称（人类可读标题，注入节点清单标题）。 */
        workflowName: string;
        /** 工作流目标描述；可为空字符串。 */
        workflowGoal: string;
        /** 流程事实源文件路径（父代理需 read 的只读 JSON 路径）。 */
        definitionPath: string;
        /** 节点清单：流程中参与流程的可调度 agent 节点（id + 人类可读名称）。 */
        nodes: Array<{
            id: string;
            label: string;
        }>;
        /** 协作组成员说明（画布含协作组时组装该段；空数组 = 不组装协作组段）。 */
        collabGroups: Array<{
            groupId: string;
            label: string;
            memberIds: string[];
        }>;
        /**
         * 协作通道（协作组段文案的分支依据）：
         *   - official = 官方 Agent Team 可用 → 指示父代理对协作组卡片调用 wf_run_node 启动官方团队；
         *   - legacy = 官方团队不可用 → 指示父代理逐个启动成员节点（既有语义）。
         * 缺省 legacy。
         */
        collabChannel?: CollabChannel;
        /** 情况2（hybrid）：父代理自身执行单元身份（被流程线连接）；情况1 缺省 null。 */
        parentNode?: {
            nodeId: string;
            nodeLabel: string;
        } | null;
        /** 系统语言名（如 '中文' / 'English'；从 DSH 用户设置读取）。注入语言规则。 */
        systemLanguage: string;
    };
    /**
     * 末段动态状态（不稳定内容，仅注入尾段，保证前中段前缀稳定）。
     * 全部字段可选：缺省即「全新运行，无断点、无暂停、无额外运行参数」。
     */
    dynamic: {
        /** 断点继续标记：true 表示本次为恢复运行（已 ok 节点不重跑，从 resumeFromNodeId 继续）。 */
        isResume?: boolean;
        /** 断点恢复时待继续的起始节点 id（isResume 为 true 时给出）。 */
        resumeFromNodeId?: string;
        resumeNodeIds?: string[];
        /** 继承链来源 run id（恢复运行上一跳记录；空为首次运行）。 */
        resumedFromRunId?: string;
        /** 暂停节点 id 清单：父代理对其中任一调用 wf_run_node（nodeId=暂停节点 id）即触发暂停门。 */
        pauseNodeIds?: string[];
        /** 本次运行的额外运行参数说明文本（如模式二 wait 阻塞调度）。 */
        runParamsText?: string;
        /** 模式二本次外部请求的用户问题（不稳定内容，仅末段注入；模式一无）。 */
        question?: string;
        /**
         * 「本次组织预算」末段文本（自主编排方案 §6.4；buildOrgBudgetText 输出）。
         * 取值口径 = 快照冻结元参数（D-13 第三层）+ 当前图规模 → **剩余量**；
         * 属动态值，只在末段注入（P2 正式接入，见 runtime-launch 的 startRun/resumeRun）。
         */
        orgBudgetText?: string;
        /** 情况2：父代理自执行单元任务块（buildParentTaskSpec 输出；本 run 内字节稳定）。 */
        parentTaskBlock?: string;
    };
}
/**
 * 编排系关键约束短语（首段与末段同时出现，供 W-02 双位测试断言与组装任务引用）。
 * 用中文面向模型（W-04）；工具名与工具 schema 描述保留英文（W-03）；措辞独立于动态值，避免前缀漂移。
 */
export declare const ORCH_HARD_CONSTRAINTS: {
    /** 父代理「仅调度不执行」核心短语（情况1 首段 + 末段重申双位）。 */
    readonly dispatchOnly: "仅编排：你只负责调度子代理，不亲自执行节点任务；不得自行搜索或处理未授权的节点输入";
    /**
     * 节点完成判定（双重汇报防治，一句话）：子代理主动 report ≠ 完成；
     * 只有 DSH 自动送达的结算通知才是节点完成的权威信号。
     */
    readonly nodeSettledSignal: "依据 Runtime 有效结算和声明产物判断执行结果；taskAcceptance=pending 时按节点任务做一次判断，随下一次 wf_run_node 或 wf_finish 的 reviews 提交 nodeId/runId/attempt/childId、status(accepted/needs-input/failed) 和简短依据；请求输入不能验收为成功，不重复评估同一结果";
    readonly inputBindings: "节点可使用宿主授权工具和会话附件上下文；显式输入合同由 Runtime 校验，WF_INPUT_REQUIRED 时通过合法输入入口补充，口头“已上传”不等于绑定成功。不用 wf_graph_patch 保存临时数据；WF_BUSY、WF_INPUT_STATE_CONFLICT、WF_INPUT_REVISION_CONFLICT 时处理原因，不循环派发";
    readonly safeTermination: "无法继续时使用既有用户干预流程或 wf_finish(status=failed) 收尾，说明失败原因；工具错误须如实处理，不伪造成功、不绕过权限或沙箱";
    /** 收尾协议：wf_finish 幂等收尾、释放锁。 */
    readonly finishIdempotent: "收尾时调用 wf_finish （只调用一次，幂等，释放运行锁）";
    /** 失败语义：节点失败需显式处置，不静默跳过。 */
    readonly failureSemantics: "不跳过失败节点；只有新的修复依据且 retryLimit 允许才重试，同一错误无新证据不重复派发";
    /** 条件连线语义：条件分支由父代理按上游实际产出语义判断。 */
    readonly conditionSemantics: "条件分支由你依据上游节点的实际产出进行语义判断";
    /** 情况2 执行者模式核心短语：你本人也是执行节点，先执行自身任务再调度。 */
    readonly executorRole: "执行+编排：你既是执行节点，也要负责调度子代理；你只执行指向自身的节点任务";
};
/** 续跑仅注入当前调度事实；图、角色与历史产出继续从稳定引用读取。 */
export declare function buildResumeOrchestrationPrompt(params: OrchestrationDirectiveParams): string;
/**
 * 情况1（纯编排）父代理提示词构建器（纯函数）。
 * 首段仅编排身份 + 完成判定信号 + 调度协议；不包含执行者模式条目。
 */
export declare function buildOrchestratorPrompt(params: OrchestrationDirectiveParams): string;
/**
 * 情况2（编排 + 自执行）父代理提示词构建器（纯函数）。
 * 首段以执行者模式取代「仅编排」；末段重申含收尾与失败语义，
 * dynamic.parentTaskBlock 为父代理自执行单元任务块（buildParentTaskSpec 输出）。
 */
export declare function buildHybridPrompt(params: OrchestrationDirectiveParams): string;
