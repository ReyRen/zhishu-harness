import test from 'node:test'
import assert from 'node:assert/strict'
import {
  DEFAULT_TARGET_URL,
  compareWebSnapshot,
  diffLines,
  isPublicAddress,
  isProxyFakeAddress,
  limitReportsPerTarget,
  migrateState,
  normalizeTargetUrl,
  normalizeText,
  parseGithubAtom,
  parseGithubCommitPage,
  parseGithubPatch,
  parseGithubUrl,
  selectCollectionTargets,
  textHash,
} from '../dsh/tracking-utils.js'

test('parses GitHub repository roots and commits branches', () => {
  assert.deepEqual(parseGithubUrl('https://github.com/deepseek-ai/deepseek-harness'), {
    owner: 'deepseek-ai', repo: 'deepseek-harness', branch: '',
  })
  assert.deepEqual(parseGithubUrl('https://github.com/acme/widgets/commits/release/v2'), {
    owner: 'acme', repo: 'widgets', branch: 'release/v2',
  })
  assert.equal(parseGithubUrl('https://example.com/feed.xml'), null)
})

test('parses GitHub Atom commits without API access', () => {
  const entries = parseGithubAtom(`<?xml version="1.0"?><feed><entry>
    <link rel="alternate" href="https://github.com/acme/widgets/commit/0123456789abcdef0123456789abcdef01234567"/>
    <title>truncated…</title><updated>2026-10-08T12:30:00Z</updated>
    <author><name>Alice &amp; Bob</name></author>
    <content type="html">&lt;pre&gt;fix: preserve full title\n\nbody&lt;/pre&gt;</content>
  </entry></feed>`)
  assert.equal(entries.length, 1)
  assert.equal(entries[0].sha, '0123456789abcdef0123456789abcdef01234567')
  assert.equal(entries[0].message, 'fix: preserve full title')
  assert.equal(entries[0].author, 'Alice & Bob')
})

test('parses bounded public commit HTML and a same-repository next-page cursor', () => {
  const sha = '0123456789abcdef0123456789abcdef01234567'
  const spec = { owner: 'acme', repo: 'widgets', branch: 'release/v2' }
  const embedded = JSON.stringify({ payload: { commitsRefRoute: { commitGroups: [{ title: 'Oct 10', commits: [{
    oid: sha, committedDate: '2026-10-10T12:00:00Z', shortMessage: 'fix: public page', authors: [{ displayName: 'Alice' }],
  }] }] } } })
  const html = `<script data-target="react-app.embeddedData" type="application/json">${embedded}</script><a rel="next" href="/acme/widgets/commits/release/v2?after=${sha}+34&amp;other=1">Next</a>`
  const parsed = parseGithubCommitPage(html, spec)
  assert.equal(parsed.entries.length, 1)
  assert.equal(parsed.entries[0].sha, sha)
  assert.equal(parsed.entries[0].author, 'Alice')
  assert.equal(parsed.entries[0].url, `https://github.com/acme/widgets/commit/${sha}`)
  assert.match(parsed.next, /after=0123456789abcdef0123456789abcdef01234567\+34/)
  assert.throws(() => parseGithubCommitPage(html.replace('/acme/widgets/commits/', '/other/widgets/commits/'), spec), /分页链接不可信/)
  assert.throws(() => parseGithubCommitPage('<html>Login</html>', spec), /无法完整核查/)
})

test('scopes historical backfill to one enabled GitHub target without rewriting web snapshots', () => {
  const targets = [
    { id: 'repo', type: 'github', enabled: true },
    { id: 'web', type: 'web', enabled: true },
    { id: 'paused', type: 'github', enabled: false },
  ]
  const currentDate = '2026-10-12'
  assert.deepEqual(selectCollectionTargets(targets, { currentDate }).map((x) => x.id), ['repo', 'web'])
  assert.deepEqual(selectCollectionTargets(targets, { targetId: 'repo', reportDate: '2026-10-10', currentDate }).map((x) => x.id), ['repo'])
  assert.throws(() => selectCollectionTargets(targets, { reportDate: '2026-10-10', currentDate }), /历史日期只能指定/)
  assert.throws(() => selectCollectionTargets(targets, { targetId: 'web', reportDate: '2026-10-10', currentDate }), /普通网页无法回溯/)
  assert.throws(() => selectCollectionTargets(targets, { targetId: 'paused', reportDate: '2026-10-10', currentDate }), /已暂停/)
})

test('extracts bounded file statistics from GitHub patches', () => {
  const files = parseGithubPatch(`diff --git a/src/a.js b/src/a.js
index 111..222 100644
--- a/src/a.js
+++ b/src/a.js
@@ -1,2 +1,2 @@
-old
+new
 same
`)
  assert.equal(files.length, 1)
  assert.equal(files[0].filename, 'src/a.js')
  assert.equal(files[0].additions, 1)
  assert.equal(files[0].deletions, 1)
  assert.equal(files[0].status, 'modified')
})

test('rejects local, private and credential-bearing URLs', () => {
  for (const url of [
    'http://localhost/x', 'http://service.local/x', 'http://127.0.0.1/x',
    'http://10.1.2.3/x', 'http://172.20.1.1/x', 'http://192.168.1.1/x',
    'http://[::1]/x', 'ftp://example.com/x', 'https://user:pass@example.com/x',
  ]) assert.throws(() => normalizeTargetUrl(url))
  assert.equal(normalizeTargetUrl('HTTPS://Example.COM:443/a//b#part'), 'https://example.com/a/b')
})

test('classifies resolved addresses conservatively', () => {
  assert.equal(isPublicAddress('8.8.8.8'), true)
  assert.equal(isPublicAddress('1.1.1.1'), true)
  assert.equal(isPublicAddress('127.0.0.1'), false)
  assert.equal(isPublicAddress('100.64.0.1'), false)
  assert.equal(isPublicAddress('169.254.1.2'), false)
  assert.equal(isPublicAddress('203.0.113.8'), false)
  assert.equal(isPublicAddress('::1'), false)
  assert.equal(isPublicAddress('fd00::1'), false)
  assert.equal(isPublicAddress('2606:4700:4700::1111'), true)
  assert.equal(isProxyFakeAddress('198.18.1.158'), true)
  assert.equal(isProxyFakeAddress('198.19.255.254'), true)
  assert.equal(isProxyFakeAddress('192.168.1.1'), false)
})

test('migrates v2 state and annotates legacy reports', () => {
  const migrated = migrateState({
    version: 2,
    reports: [{ id: 'old', source: DEFAULT_TARGET_URL, headline: 'legacy' }],
    automation: { sessionId: 'session-1', taskId: 'task-1' },
  }, '2026-10-08T00:00:00.000Z')
  assert.equal(migrated.version, 4)
  assert.equal(migrated.targets.length, 1)
  assert.equal(migrated.targets[0].id, 'deepseek-harness')
  assert.equal(migrated.targets[0].name, 'DeepSeek Harness')
  assert.equal(migrated.reports[0].targetId, 'deepseek-harness')
  assert.equal(migrated.reports[0].targetName, 'DeepSeek Harness')
  assert.equal(migrated.reports[0].sourceType, 'github')
  assert.equal(migrated.automation.sessionId, 'session-1')
})

test('preserves an explicitly empty v3 target list and drops orphan reports', () => {
  const migrated = migrateState({ version: 3, targets: [], reports: [{ id: 'orphan', targetId: 'gone' }] })
  assert.deepEqual(migrated.targets, [])
  assert.deepEqual(migrated.reports, [])
})

test('migrates same-day scheduled web reports to yesterday and deduplicates manual reports', () => {
  const generatedAt = new Date(2026, 9, 9, 11, 0).toISOString()
  const migrated = migrateState({
    version: 3,
    targets: [{ id: 'web', name: 'Web', url: 'https://example.com/changelog', type: 'web' }],
    reports: [
      { id: 'scheduled', targetId: 'web', sourceType: 'web', reportDate: '2026-10-09', generatedAt, trigger: 'scheduled' },
      { id: 'manual', targetId: 'web', sourceType: 'web', reportDate: '2026-10-08', generatedAt: new Date(2026, 9, 8, 20, 0).toISOString(), trigger: 'manual' },
      { id: 'late-explicit', targetId: 'web', sourceType: 'web', reportDate: '2026-10-07', generatedAt: new Date(2026, 9, 7, 22, 0).toISOString(), trigger: 'scheduled' },
    ],
  })
  assert.equal(migrated.version, 4)
  assert.equal(migrated.reports.length, 2)
  assert.equal(migrated.reports[0].id, 'scheduled')
  assert.equal(migrated.reports[0].reportDate, '2026-10-08')
  assert.equal(migrated.reports[1].id, 'late-explicit')
  assert.equal(migrated.reports[1].reportDate, '2026-10-07')
})

test('limits reports independently for each target', () => {
  const reports = [
    ...Array.from({ length: 65 }, (_, index) => ({ id: `a-${index}`, targetId: 'a' })),
    ...Array.from({ length: 63 }, (_, index) => ({ id: `b-${index}`, targetId: 'b' })),
  ]
  const limited = limitReportsPerTarget(reports, 60)
  assert.equal(limited.filter((report) => report.targetId === 'a').length, 60)
  assert.equal(limited.filter((report) => report.targetId === 'b').length, 60)
  assert.equal(limited.length, 120)
  assert.equal(limited[0].id, 'a-0')
})

test('produces bounded line diffs with previous-to-current semantics', () => {
  const diff = diffLines('alpha\nbeta\nremoved', 'alpha\nbeta changed\nadded', 1)
  assert.deepEqual(diff.added, ['beta changed'])
  assert.deepEqual(diff.removed, ['beta'])
  assert.equal(diff.addedCount, 2)
  assert.equal(diff.removedCount, 2)
  assert.equal(diff.truncated, true)
})

test('tracks HTML main content without sidebar navigation noise', () => {
  const html = '<nav>统信 UOS 系统安装指南</nav><main><h1>更新日志</h1><p>5.7.6 修复任务问题</p></main><footer>版权</footer>'
  assert.equal(normalizeText(html, 'text/html'), '更新日志\n5.7.6 修复任务问题')
})

test('upgrades legacy full-page snapshots without reporting removed navigation', () => {
  const legacy = { hash: textHash('侧边栏\n更新日志\n5.7.6'), text: '侧边栏\n更新日志\n5.7.6' }
  const unchanged = compareWebSnapshot(legacy, '更新日志\n5.7.6', 2)
  assert.equal(unchanged.changed, false)
  assert.equal(unchanged.diff.removedCount, 0)
  const changed = compareWebSnapshot(legacy, '更新日志\n5.7.7', 2)
  assert.equal(changed.changed, true)
  assert.deepEqual(changed.diff.added, ['5.7.7'])
})

test('normalizes HTML and structured JSON into stable text', () => {
  const html = normalizeText('<style>x{}</style><!--noise--><h1>Hello</h1><script>bad()</script><p>World&nbsp; now</p>', 'text/html')
  assert.equal(html, 'Hello\nWorld now')
  const first = normalizeText('{"b":2,"generated_at":"today","a":1}', 'application/json')
  const second = normalizeText('{"a":1,"generated_at":"tomorrow","b":2}', 'application/json')
  assert.equal(first, second)
  assert.equal(textHash(first), textHash(second))
})
