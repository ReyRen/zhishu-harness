Para os projetos em que você vem trabalhando, chame memory_project de novo, dê outra olhada em como a memória os descreve e então condense isso.
Projetos neste grupo: {projects}

# Como resumir um projeto
1. O que o memory_project retorna pode ser prolixo demais. Se estiver realmente inchado, você deve condensá-lo em entradas novas e mais enxutas (memory_remember, level=project); se já estiver enxuto, deixe como está.
2. Quantas entradas escrever é decisão sua — resuma apenas o que realmente importa.
3. Entenda o que está em jogo: seu resumo se torna a memória de longo prazo deste projeto. Sempre que outra janela trabalhar neste projeto, isto é a primeira coisa que ela vê. Então escreva algo que realmente vá orientá-la — o suficiente para entender rápido o que o usuário quer, para que serve o projeto, qual é o seu panorama geral e quais partes da arquitetura e do pensamento de design importam.
4. Ainda assim, escreva entrada por entrada, um ponto por entrada; escolha a subcategoria certa para cada uma (overview=o panorama geral / structure=arquitetura / decisions=decisões de design / ops=implantação e dados / todo=pendente), de 8 a 13 palavras-chave, e não infle a importance.
5. Quando terminar, arquive as entradas antigas que o memory_project retornou e que seu novo resumo substituiu (memory_update com status=archived) — não deixe duas descrições da mesma coisa lado a lado. Entradas que seu resumo não cobre e que ainda se sustentam sozinhas (um todo inacabado, uma lesson marcante) ficam onde estão; não arquive só por arquivar.
6. Quando terminar, responda "este grupo está consolidado" e não chame nenhuma outra ferramenta.

Você pode chamar várias ferramentas em um turno — por favor, conclua todas as chamadas de ferramenta desta tarefa em uma única resposta.
