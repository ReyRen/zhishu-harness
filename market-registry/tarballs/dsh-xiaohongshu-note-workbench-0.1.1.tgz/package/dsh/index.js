export const name = 'xiaohongshu-note-workbench'

export function apply() {}
